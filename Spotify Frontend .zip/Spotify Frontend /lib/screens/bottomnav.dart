import 'package:flutter/material.dart';
//import 'package:flutter_application_1/screen/home.dart';

import 'package:spotify/screens/comingsoon.dart';
import 'package:spotify/screens/dow.dart';


import 'package:spotify/screens/homepage1.dart';
import 'package:spotify/screens/more.dart';
import 'package:spotify/screens/search.dart';


class NavBar extends StatefulWidget {
  const NavBar({super.key});

  @override
  State<NavBar> createState() => _NavBarState();
}

class _NavBarState extends State<NavBar> {
  int currentIndexs = 0;
  final List screens = [
    const HomePage(),
    const Search(),
    const Dow(),
    const More(),
    const Comingsoon(),
  ];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        extendBodyBehindAppBar: true,
        backgroundColor: Colors.black,
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          // leading: Image.asset(
          //   "assets/a.jpeg", 
            
          // ),

          leading: Padding(
            padding: const EdgeInsets.all(6.0),
            child: CircleAvatar(
                radius: 50,
                backgroundImage: AssetImage("assets/a.jpeg"),
            ),
          ),
          actions: [
          
            // OutlinedButton(
            //     onPressed: () {},
            //     child: const Text(
            //       "TV Shows",
            //       style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            //     )),
            Padding(
              padding: const EdgeInsets.only(right: 125, top: 14),
              child: GestureDetector(
                onTap: () {},
                child: const Text(
                  "Good Morning",
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.bold),
                ),
              ),
            ),

              Padding(
              padding: const EdgeInsets.all(8.0),
              child: IconButton(icon: Icon(
                Icons.collections_bookmark_outlined,
                color: Colors.white,
              ),
              onPressed: (){},
              ),
            ),

              Padding(
              padding: const EdgeInsets.all(8.0),
              child: IconButton(icon: Icon(
                Icons.notifications,
                color: Colors.white,
              ),
              onPressed: (){},
              ),
            ),
            // Padding(
            //   padding: const EdgeInsets.all(10.0),
            //   child: GestureDetector(
            //     onTap: () {
            //       print("MOV is called");
            //     },
            //     child: const Text(
            //       "Movies",
            //       style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            //     ),
            //   ),
            // ),
            // Padding(
            //   padding: const EdgeInsets.all(10.0),
            //   child: GestureDetector(
            //     onTap: () {},
            //     child: const Text(
            //       "My List",
            //       style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            //     ),
            //   ),
            // )
          ],
        ),

       
        body: screens[currentIndexs],
        bottomNavigationBar: BottomNavigationBar(
            currentIndex: currentIndexs,
            type: BottomNavigationBarType.fixed,
            onTap: (value) {
              setState(() {
                currentIndexs = value;
              });
            },
            backgroundColor: Colors.black,
            selectedItemColor: Colors.white,
            unselectedItemColor: Colors.white.withOpacity(.60),
            selectedFontSize: 13,
            unselectedFontSize: 10,
            items: const [
              BottomNavigationBarItem(label: "Home", icon: Icon(Icons.home)),
              BottomNavigationBarItem(
                  label: "Search", icon: Icon(Icons.search)),
              BottomNavigationBarItem(
                  label: "Your Library", icon: Icon(Icons.library_books)),
              //BottomNavigationBarItem(label: "More", icon: Icon(Icons.add)),
              //BottomNavigationBarItem(
                 // label: "Coming Soon", icon: Icon(Icons.tv)),
            ]),
      ),

    );
  }
}
