import 'package:flutter/material.dart';

class Dow extends StatelessWidget {
  const Dow({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text('Screen 3')),
      body: Center(child: Text('This is Screen 3')),
    );
  }
}