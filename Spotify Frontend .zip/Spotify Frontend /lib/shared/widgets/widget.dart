import 'package:flutter/material.dart';

class WIDGET extends StatelessWidget {
  const WIDGET({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Container(
                height: 60,
                width: 150,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 55, 53, 53),
                  //borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 60, // Make the image square
                      height: 60, // Make the image square
                      decoration: BoxDecoration(
                        // Align the image at the start of the container
                        image: DecorationImage(
                          image: AssetImage('assets/liked.png'),
                          fit: BoxFit.cover,
                          alignment: Alignment.centerLeft,
                        ),
                      ),
                    ),
                    SizedBox(width: 8), // Add a small gap between image and text
                    Text(
                      "Liked Songs",
                      style: TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ],
                ),
              ),
            ),
            SizedBox(width:40),
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Container(
                height: 60,
                width: 150,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 55, 53, 53),
                  //borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 60, // Make the image square
                      height: 60, // Make the image square
                      decoration: BoxDecoration(
                        // Align the image at the start of the container
                        image: DecorationImage(
                          image: AssetImage('assets/barbie.png'),
                          fit: BoxFit.cover,
                          alignment: Alignment.centerLeft,
                        ),
                      ),
                    ),
                    SizedBox(width: 8), // Add a small gap between image and text
                    Flexible(
                      child: Text(
                        "Barbie Official Playlist",
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 5), // Add spacing between rows
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Container(
                height: 60,
                width: 150,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 55, 53, 53),
                  //borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 60, // Make the image square
                      height: 60, // Make the image square
                      decoration: BoxDecoration(
                        // Align the image at the start of the container
                        image: DecorationImage(
                          image: AssetImage('assets/blankspace.jpeg'),
                          fit: BoxFit.cover,
                          alignment: Alignment.centerLeft,
                        ),
                      ),
                    ),
                    SizedBox(width: 8), // Add a small gap between image and text
                    Flexible(
                      child: Text(
                        "Blank Space - Taylor Swift",
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ), SizedBox(width:40),
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Container(
                height: 60,
                width: 150,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 55, 53, 53),
                  //borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 60, // Make the image square
                      height: 60, // Make the image square
                      decoration: BoxDecoration(
                        // Align the image at the start of the container
                        image: DecorationImage(
                          image: AssetImage('assets/sour.webp'),
                          fit: BoxFit.cover,
                          alignment: Alignment.centerLeft,
                        ),
                      ),
                    ),
                    SizedBox(width: 8), // Add a small gap between image and text
                    Flexible(
                      child: Text(
                        "Olivia Rodrigo",
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
        SizedBox(height: 5), // Add spacing between rows
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Container(
                height: 60,
                width: 150,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 55, 53, 53),
                  //borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 60, // Make the image square
                      height: 60, // Make the image square
                      decoration: BoxDecoration(
                        // Align the image at the start of the container
                        image: DecorationImage(
                          image: AssetImage('assets/flowers.webp'),
                          fit: BoxFit.cover,
                          alignment: Alignment.centerLeft,
                        ),
                      ),
                    ),
                    SizedBox(width: 8), // Add a small gap between image and text
                    Flexible(
                      child: Text(
                        "Flowers",
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ), SizedBox(width:40),
            Padding(
              padding: const EdgeInsets.only(top: 50),
              child: Container(
                height: 60,
                width: 150,
                decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 55, 53, 53),
                  //borderRadius: BorderRadius.circular(20),
                ),
                child: Row(
                  children: [
                    Container(
                      width: 60, // Make the image square
                      height: 60, // Make the image square
                      decoration: BoxDecoration(
                        // Align the image at the start of the container
                        image: DecorationImage(
                          image: AssetImage('assets/blair.webp'),
                          fit: BoxFit.cover,
                          alignment: Alignment.centerLeft,
                        ),
                      ),
                    ),
                    SizedBox(width: 8), // Add a small gap between image and text
                    Flexible(
                      child: Text(
                        "Blair Waldorf Energy",
                        style: TextStyle(color: Colors.white, fontSize: 12),
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ],
        ),
      ],
    );
  }
}
