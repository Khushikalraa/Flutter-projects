import 'package:flutter/material.dart';

class TUNE extends StatelessWidget {
  const TUNE({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.only(left: 45,top: 20),
          child: Container(
            child: Row(
              children: [
               // const TextField(style: TextStyle(color: Colors.white),),
               Text("Jump back in..",style: TextStyle(color: Colors.white),),
                IconButton(
                        onPressed: () {
                          // Define the action when the IconButton is pressed
                          // For example, you can show a snackbar or navigate to a new screen.
                        },
                        icon: Icon(Icons.music_note),
                        color: Colors.white,
                // Container(
                //   width:300,
                //   height:300,
                //   child: Image.asset("assets/a.jpeg")
                
            ),],
            ),
          ),
        ),

     

      ],
    );
  }
}