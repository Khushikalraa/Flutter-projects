import 'package:flutter/material.dart';

class AP extends StatelessWidget {
  const AP({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(
      children: [
        Row(
           //mainAxisAlignment: MainAxisAlignment.center,
            children: [
              Padding(
                padding: const EdgeInsets.only(left: 10),
                child: Container(
                  height: 25,
                  width: 150,
                  decoration: BoxDecoration(
                  color: const Color.fromARGB(255, 55, 53, 53),
                  borderRadius: BorderRadius.circular(20),
                ),
                child: Center(child: Text("Music",style: TextStyle(color: Colors.white, fontSize: 12),),),
              ),
              ),
              
              const SizedBox(width: 20),

              Container(
                height: 25,
                width: 150,
                
                decoration: BoxDecoration(
                color: const Color.fromARGB(255, 55, 53, 53),
                borderRadius: BorderRadius.circular(20),
                
              ),
              child: Center(child: Text("Podcasts",style: TextStyle(color: Colors.white, fontSize: 12),),),
         ) ],
          ),
        
      ],
    );
  }
}