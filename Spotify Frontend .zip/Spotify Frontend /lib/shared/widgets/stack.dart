import 'package:flutter/material.dart';

class ST extends StatelessWidget {
  const ST({super.key});

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        Container(
          height: 400,
          width:300,
          child: Image.asset("assets/bewitched.png")),
        Positioned(
          bottom: 200,
          left: 20,
          child: Row(
            children: [
              
              Row(
                  children: [
                   // Icon(Icons.add,color: Colors.black,),
                    Padding(
                      padding: const EdgeInsets.only(right: 60,bottom: 120),
                      child: Text("Laufey - Bewitched",style: TextStyle(fontSize: 10,fontWeight: FontWeight.bold,color: Colors.white),),
                    ),
                    Padding(
                      padding: const EdgeInsets.only(left:50.0,bottom: 110),
                      child: Container(
                        
                        
                        width: 65,
                        height: 30,
                        decoration: BoxDecoration(
                          borderRadius: BorderRadius.circular(20),
                          color: Color.fromARGB(255, 55, 53, 53),
                        ),
                        //color: Colors.white,
                        child: Row( mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                          children: [

                          // Padding(
                          //  padding: const EdgeInsets.only(left: 10),
                            Icon(Icons.volume_up, color: Colors.white,),
                         // ),
                         // SizedBox(width:10),
                         //  Padding(
                            //padding: const EdgeInsets.only(),
                            Icon(Icons.more, color: Colors.white,),
                        //  ),
                        ],)
                      ),
                    )
                  ],



                  
                ),
              
              
              // Padding(
              //   padding: const EdgeInsets.only(left: 25,right: 25),
              //   child: Container(
              //     padding: EdgeInsets.only(left: 20,right: 20, top: 5,bottom: 5),
              //     child:
              //      Text("Play",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: const Color.fromARGB(255, 255, 255, 255),backgroundColor: Colors.black),)),
              // ),
              
              
              // Padding(
              //   padding: const EdgeInsets.only(left: 25,right: 25),
              //   child: Row(
              //     children: [
              //       Icon(Icons.info,color: Colors.white,),
              //       Text("Info",style: TextStyle(fontSize: 20,fontWeight: FontWeight.bold,color: Colors.black),),
              //     ],
              //   ),
              // )

             
        
            ],
          ),
          
        )
      ],
    );
    
  }
}