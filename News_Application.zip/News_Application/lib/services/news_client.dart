import 'package:dio/dio.dart';

class NewsClient {
  final Dio _dio = Dio();

  getNewsDataFromAPI() async {
    String newsURL =
        "https://newsapi.org/v2/top-headlines?country=us&apiKey=0227360ae9ce4e12a4a68d5d6ef3f73f";
    try {
      var response = await _dio.get(newsURL);

      print("this is the news data from the API ${response.data}");
      return response.data;
    } catch (error) {
      print("Error in fetching data from API $error");
    }
  }
}
