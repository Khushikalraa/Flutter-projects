import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:ted/screens/homepage.dart';

void main(){
  runApp(MaterialApp(
    debugShowCheckedModeBanner: false,
    home: HomePage()
  ));
}