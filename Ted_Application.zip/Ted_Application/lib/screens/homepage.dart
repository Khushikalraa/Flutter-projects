import 'package:flutter/material.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.red,
          leading: IconButton(onPressed: () {}, icon: Icon(Icons.search)),
          actions: [
            Padding(
              padding: const EdgeInsets.only(right: 160.0),
              child: Center(
                child: Text(
                  "TED",
                  style: TextStyle(fontSize: 30),
                ),
              ),
            )
          ],
        ),
        
        body: SingleChildScrollView(
          child: Padding(
            padding: const EdgeInsets.only(top: 20.0),
            child: Column(
              children: [
                Container(
                  width: double.infinity, // Full width
                  height: 250,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Stack(
                    children: [
                      Image.asset(
                        'assets/a.jpeg', // Replace with your image path
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 210.0),
                        child: Center(
                          child: Container(
                            height: 20,
                            width: 550,
                            color: const Color.fromARGB(104, 0, 0, 0),
                            child: Center(child: Text("Falls Park",style: TextStyle(color: Colors.white),)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  width: double.infinity, // Full width
                  height: 250,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Stack(
                    children: [
                      Image.asset(
                        'assets/b.jpeg', // Replace with your image path
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 210.0),
                        child: Center(
                          child: Container(
                            height: 20,
                            width: 550,
                            color: const Color.fromARGB(104, 0, 0, 0),
                            child: Center(child: Text("Downtown",style: TextStyle(color: Colors.white),)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20,),
                Container(
                  width: double.infinity, // Full width
                  height: 250,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Stack(
                    children: [
                      Image.asset(
                        'assets/c.jpeg', // Replace with your image path
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 210.0),
                        child: Center(
                          child: Container(
                            height: 20,
                            width: 550,
                            color: const Color.fromARGB(104, 0, 0, 0),
                            child: Center(child: Text("Downtown", style: TextStyle(color: Colors.white))),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
                Container(
                  width: double.infinity, // Full width
                  height: 250,
                  decoration: BoxDecoration(
                    color: Colors.white,
                    borderRadius: BorderRadius.circular(12),
                  ),
                  child: Stack(
                    children: [
                      Image.asset(
                        'assets/d.jpeg', // Replace with your image path
                        fit: BoxFit.cover,
                        width: double.infinity,
                        height: double.infinity,
                      ),
                      Padding(
                        padding: const EdgeInsets.only(top: 210.0),
                        child: Center(
                          child: Container(
                            height: 20,
                            width: 550,
                            color: const Color.fromARGB(104, 0, 0, 0),
                            child: Center(child: Text("Chicago Beach",style: TextStyle(color: Colors.white),)),
                          ),
                        ),
                      ),
                    ],
                  ),
                ),
                SizedBox(height: 20),
              ],
            ),
          ),
        ),
      ),
    );
  }
}


