import 'package:flutter/material.dart';

class Comingsoon extends StatelessWidget {
  const Comingsoon({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Image.asset("assets/netflix_logo0.png"),
        backgroundColor: Colors.black,
        title: Text('New & Hot'),
        actions: [
          Icon(Icons.add),
          SizedBox(width: 5),
          Icon(Icons.notifications),
          SizedBox(width: 5),
          Icon(Icons.stream),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Chip(
                    label: Text(
                      "🫶🏻 Coming Soon",
                      style: TextStyle(color: Colors.white),
                    ),
                    backgroundColor: Colors.black,
                  ),
                  SizedBox(width: 10),
                  Chip(
                    label: Text(
                      "😍 Everyone's watching",
                      style: TextStyle(color: Colors.white),
                    ),
                    backgroundColor: Colors.black,
                  ),
                ],
              ),
              SizedBox(height: 40),
              Row(
                children: [
                  Container(
                    width: 100, // Adjust the width as needed
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("31st august", style: TextStyle(fontSize: 20)),
                        SizedBox(height: 10),
                       // Text("1st SEP", style: TextStyle(fontSize: 20)),
                      ],
                    ),
                  ),
                  SizedBox(width: 20),
                  Container(
                    height: 200,
                    width: 200, // Adjust the width as needed
                    child: Column(
                      children: [
                        Image.asset(
                          'assets/wednesday.webp',
                          height: 200, // Adjust the height as needed
                          fit: BoxFit.cover,
                        ),
                      ],
                    ),
                  ),
                ],
              ),
              SizedBox(height:50),
              Row(
                children: [
                  Container(
                    width: 100, // Adjust the width as needed
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("20th december", style: TextStyle(fontSize: 20)),
                        SizedBox(height: 10),
                       // Text("1st SEP", style: TextStyle(fontSize: 20)),
                      ],
                    ),
                  ),
                  SizedBox(width: 20),
                  Container(
                    width: 200, // Adjust the width as needed
                    child: Column(
                      children: [
                        Image.asset(
                          'assets/serena.jpeg',
                          height: 200,
                          width: 200, // Adjust the height as needed
                          fit: BoxFit.cover,
                        ),
                      ],
                    ),
                  ),
                ],
              ),SizedBox(height:50),
              Row(
                children: [
                  Container(
                    width: 100, // Adjust the width as needed
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("10th january", style: TextStyle(fontSize: 20)),
                        SizedBox(height: 10),
                       // Text("1st SEP", style: TextStyle(fontSize: 20)),
                      ],
                    ),
                  ),
                  SizedBox(width: 20),
                  Container(
                    width: 200, // Adjust the width as needed
                    child: Column(
                      children: [
                        Image.asset(
                          'assets/duke.jpeg',
                          height: 200, // Adjust the height as needed
                          fit: BoxFit.cover,
                        ),
                      ],
                    ),
                  ),
                  
                ],
              ),
              SizedBox(height:40),
              
              Row(
                children: [
                  Container(
                    width: 100, // Adjust the width as needed
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text("8th february", style: TextStyle(fontSize: 20)),
                        SizedBox(height: 10),
                       // Text("1st SEP", style: TextStyle(fontSize: 20)),
                      ],
                    ),
                  ),
                  SizedBox(width: 20),
                  Container(
                    width: 200, // Adjust the width as needed
                    child: Column(
                      children: [
                        Image.asset(
                          'assets/ben.jpeg',
                          height: 200, // Adjust the height as needed
                          fit: BoxFit.cover,
                        ),
                      ],
                    ),
                  ),
                  
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }
}
