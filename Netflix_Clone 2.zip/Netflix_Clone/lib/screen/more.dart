import 'package:flutter/material.dart';

class More extends StatelessWidget {
  const More({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        appBar: AppBar(
          leading: Image.asset(
            "assets/netflix_logo0.png",
          ),
          title: const Text('My List'),
          backgroundColor: Colors.black,
          actions: const [Icon(Icons.edit)],
        ),
        body: Column(
          children: [
            Expanded(
              child: SingleChildScrollView(
                child: Container(
                  color: Colors.black, // Set the background color to black
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Padding(
                        padding: const EdgeInsets.only(top: 8.0),
                        child: const Row(
                          children: [
                            Padding(
                              padding: EdgeInsets.only(left: 8.0),
                              child: Text(
                                "sort by",
                                style: TextStyle(
                                    fontSize: 15,
                                    color: Colors.white), // Set text color to white
                              ),
                            ),
                            Spacer(), // Add a Spacer to push "sort by" to the left
                          ],
                        ),
                      ),
                      SizedBox(height: 10),
                      const SizedBox(height: 5),
                      const Row(
                        children: [
                          Text(
                            "Suggestions",
                            style: TextStyle(
                                fontSize: 25,
                                color: Colors.white), // Set text color to white
                            textAlign: TextAlign.start,
                          ),
                          Icon(Icons.arrow_drop_down,
                              color: Colors.white), // Set icon color to white
                        ],
                      ),
                      const SizedBox(height: 5),

                      // List items
                      _buildListItem(
                        context,
                        'assets/poster1.webp',
                        'Girlmore Girls',
                      ),
                      const SizedBox(height: 20),

                      _buildListItem(
                        context,
                        'assets/poster2.webp',
                        'YOU',
                      ),
                      const SizedBox(height: 20),

                      _buildListItem(
                        context,
                        'assets/poster3.jpeg',
                        'DEFENDERS',
                      ),
                      const SizedBox(height: 20),

                      _buildListItem(
                        context,
                        'assets/poster4.jpeg',
                        '13 Reasons Why',
                      ),
                      const SizedBox(height: 20),

                      _buildListItem(
                        context,
                        'assets/poster5.jpeg',
                        'Mazey Day',
                      ),
                      const SizedBox(height: 20),

                      _buildListItem(
                        context,
                        'assets/wednesday.webp',
                        'Wednesday',
                      ),
                    ],
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildListItem(BuildContext context, String imagePath, String title) {
    return Container(
      width: double.infinity,
      height: 100,
      color: Colors.black,
      child: Row(
        mainAxisAlignment: MainAxisAlignment.spaceEvenly,
        children: [
          // Wrap the Image.asset widget with AspectRatio
          AspectRatio(
            aspectRatio: 1.0, // Maintain a square aspect ratio
            child: Image.asset(
              imagePath,
              fit: BoxFit.cover, // Preserve the aspect ratio and cover the space
            ),
          ),
          const SizedBox(width: 5),
          // Add a Text widget
          Expanded(
            child: Text(
              title,
              style: TextStyle(fontSize: 20, color: Colors.white),
            ),
          ),
          // Add some spacing between the Text and Icon
          const SizedBox(width: 5),
          // Add an Icon
          const Icon(Icons.play_arrow_rounded, color: Colors.white),
        ],
      ),
    );
  }
}
