import 'package:flutter/material.dart';

class Search extends StatelessWidget {
  const Search({super.key});

  @override
   Widget build(BuildContext context) {
    return MaterialApp(
      home: MyHomePage(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class MyHomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        leading: Icon(Icons.search),
        backgroundColor: Colors.black,
        //title: Text('App with TextField in AppBar'),
        title: PreferredSize(
          preferredSize: Size.fromHeight(48.0),
          child: Padding(
            padding: EdgeInsets.only(top: 0),
            child: TextField(
              style: TextStyle(color: Colors.white),

              decoration: InputDecoration(
                
                
                hintText: 'Search...', hintStyle: TextStyle(color: Colors.white), 
                border: OutlineInputBorder(),
              ),
            ),
          ),
        ),
      ),
      body: Center(
        //child: Text('Content goes here'),
      ),
    );
  }
}



