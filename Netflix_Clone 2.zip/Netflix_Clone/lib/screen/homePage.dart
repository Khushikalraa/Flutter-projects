
import 'package:flutter/material.dart';
// import 'package:flutter_application_1/screen/comingsoon.dart';
// import 'package:flutter_application_1/screen/dow.dart';
// import 'package:flutter_application_1/screen/home.dart';
// import 'package:flutter_application_1/screen/more.dart';
// import 'package:flutter_application_1/screen/search.dart';
import 'package:flutter_application_1/widgets/Mylist.dart';
import 'package:flutter_application_1/widgets/Netflix%20originals.dart';
import 'package:flutter_application_1/widgets/nf_stack.dart';
import 'package:flutter_application_1/widgets/preview.dart';

class HomePage extends StatefulWidget {
  const HomePage({super.key});
  

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> {
  int currentIndex = 0;

 //List<Widget> screens = [Home(), Dow(), Search(), Comingsoon(), More()];
  @override
  Widget build(BuildContext context) {
    return SafeArea(
      
    child: Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
          backgroundColor: Colors.black,
          leading: Image.asset(
            "assets/netflix_logo0.png",
          ),
          actions: [
            // OutlinedButton(
            //     onPressed: () {},
            //     child: const Text(
            //       "TV Shows",
            //       style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
            //     )),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: GestureDetector(
                onTap: () {},
                child: const Text(
                  "TV Shows",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: GestureDetector(
                onTap: () {
                  print("MOV is called");
                },
                child: const Text(
                  "Movies",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.all(10.0),
              child: GestureDetector(
                onTap: () {},
                child: const Text(
                  "My List",
                  style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),
                ),
              ),
            )
          ],
        ),
      // appBar: AppBar(leading: Image.asset("assets/netflix_logo0.png"), 
      // backgroundColor: Colors.transparent,
      // actions:[
      // OutlinedButton(
      //   onPressed: () {},
      //   child: const Text(
      //     "TV Shows",
      //     style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)
      //   )
      // ),
      // OutlinedButton(
      //   onPressed: () {},
      //   child: const Text(
      //     "Movies",
      //     style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)
      //   )
      // ),
      // OutlinedButton(
      //   onPressed: () {},
      //   child: const Text(
      //     "My List",
      //     style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold)
      //   )
      // ),
      
      //  [Padding(
      //    padding: const EdgeInsets.all(10.0),
      //    child: Text("TV Shows", style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),),
      //  ),
      //  Padding(
      //    padding: const EdgeInsets.all(10.0),
      //    //padding: EdgeInsets.only(left: 5.0, top:20)
      //    child: GestureDetector
      //    ( onTap: () {
           
      //    },
      //     child: Text("TV Shows", style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),)),
      //  ),
      //   Padding(
      //    padding: const EdgeInsets.all(10.0),
      //    //padding: EdgeInsets.only(left: 5.0, top:20)
      //    child: GestureDetector
      //    ( onTap: () {
           
      //    },
      //     child: Text("Movies", style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),)),
      //  ),
      //  Padding(
      //    padding: const EdgeInsets.all(10.0),
      //    //padding: EdgeInsets.only(left: 5.0, top:20)
      //    child: GestureDetector
      //    ( onTap: () {
           
      //    },
      //     child: Text("My List", style: TextStyle(fontSize: 25, fontWeight: FontWeight.bold),)),
      //  ),
      
      // //  ],),
      
      // //backgroundColor: Color.fromARGB(255, 0, 0, 0),
      // ], ),

      

      //BOTTOM BAR
      body: IndexedStack(
          index: currentIndex,
          children: [
            SingleChildScrollView(
              child: Container(
                color: Colors.black,
                width: double.infinity,
                child: Column(
                  children: [NFSTACK(), PREVIEW(), MYLIST(), NF(),],
                ),
              ),
            ),
        //     screens[currentIndex],
        //   ],
        // ),
        // bottomNavigationBar: BottomNavigationBar(
        //   currentIndex: currentIndex,
        //   type: BottomNavigationBarType.fixed,
        //   onTap: (index) {
        //     setState(() {
        //       currentIndex = index;
        //     });
        //   },
        //   backgroundColor: Colors.black,
        //   items: const [
        //     BottomNavigationBarItem(
        //       label: "Home",
        //       icon: Icon(Icons.home, color: Colors.black),
        //     ),
        //     BottomNavigationBarItem(
        //       label: "Download",
        //       icon: Icon(Icons.download, color: Colors.black),
        //     ),
        //     BottomNavigationBarItem(
        //       label: "Search",
        //       icon: Icon(Icons.search, color: Colors.black),
        //     ),
        //     BottomNavigationBarItem(
        //       label: "Comingsoon",
        //       icon: Icon(Icons.tv, color: Colors.black),
        //     ),
        //     BottomNavigationBarItem(
        //       label: "More",
        //       icon: Icon(Icons.add, color: Colors.black),
        //     ),
        //   ],
        // ),
     ], ),
     ), );
  }
}