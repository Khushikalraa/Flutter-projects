import 'package:flutter/material.dart';

class dow extends StatelessWidget {
  const dow({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SafeArea(
      child: Scaffold(
        backgroundColor: Colors.black,
        appBar: AppBar(
          leading: Image.asset(
            "assets/netflix_logo0.png",
          ),
          actions: [Padding(
            padding: const EdgeInsets.only(right:8.0),
            child: Icon(Icons.info),
          )],
          title: Text('Downloads'),
          backgroundColor: Colors.black,
        ),
        
        body: Column(
          children: [
            Padding(
              padding: const EdgeInsets.only(top: 20.0),
              child: Container(
                width: double.infinity,
                height: 100,
                color: Colors.black,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.spaceEvenly,
                  children: [
                    // Add an Image
                    Image.asset(
                      'assets/queen.jpg',
                      width: 100,
                      height: 100,
                    ),
                    const SizedBox(width: 5),
                    // Add a Text widget
                    const Column(
                      children: [
                        Text(
                          'Queen Charlotte',
                          style: TextStyle(fontSize: 20, color: Colors.white),
                        ),
                        SizedBox(height: 15),
                        Text(
                          'Season 1: 10 episodes',
                          style: TextStyle(fontSize: 15, color: Colors.white),
                        ),
                      ],
                    ),
                    const SizedBox(width: 5),
                    const Icon(Icons.download_done, color: Colors.white),
                  ],
                ),
              ),
            ),
            SizedBox(
              height: 10,
            ),
            
            const SizedBox(
              height: 0,
            ),

            Align(
              alignment: Alignment.bottomCenter,
              child: Container(
                height: 50,
                width: 250,
                color: Colors.black,
                child: const Center(
                  child: Text(
                    "Explore more to download",
                    style: TextStyle(fontSize: 10, color: Colors.white),
                  ),
                ),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
