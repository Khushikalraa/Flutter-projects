import 'package:flutter/material.dart';

class MYLIST extends StatelessWidget {
  const MYLIST({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(

      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("My List", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        SizedBox(height:10),
        Container(

          width: double.infinity,
          height: 140,
          child: ListView(
            padding: const EdgeInsets.all(5),
            scrollDirection: Axis.horizontal,
            children:  [ Container(
              height: 200,
              width: 100,
              
             // radius: 50,
              child: Image.asset("assets/dogs.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            Container(
              height: 200,
              width: 100,
              
             // radius: 50,
              child: Image.asset("assets/thirteen_reasons.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            Container(
              height: 200,
              width: 100,
              
             // radius: 50,
              child: Image.asset("assets/sintel.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            Container(
              height: 200,
              width: 100,
              
             // radius: 50,
              child: Image.asset("assets/stranger_things.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            Container(
              height: 200,
              width: 100,
              
             // radius: 50,
              child: Image.asset("assets/witcher.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            
              
              
            //   CircleAvatar(
            //   radius: 50,
            //   backgroundImage: AssetImage("assets/thirteen_reasons.jpg"),
            //   // child: Image.asset("assets/dogs.jpg"),
            // ),
           
            // CircleAvatar(
            //   radius: 50,
            //   backgroundImage: AssetImage("assets/sintel.jpg"),
            //   //child: Image.asset("assets/dogs.jpg"),
            // ),
            // CircleAvatar(
            //   radius: 50,
            //   backgroundImage: AssetImage("assets/stranger_things.jpg"),
            //   //child: Image.asset("assets/dogs.jpg"),
            // ),
            // CircleAvatar(
            //   radius: 50,
            //   //child: Image.asset("assets/dogs.jpg"),
            //   backgroundImage: AssetImage("assets/witcher.jpg"),
            // ),
            
            ], 
          ),
        )



      ],
    );
  }
}