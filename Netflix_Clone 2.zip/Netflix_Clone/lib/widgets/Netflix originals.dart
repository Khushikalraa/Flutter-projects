import 'package:flutter/material.dart';

class NF extends StatelessWidget {
  const NF({super.key});

  @override
  Widget build(BuildContext context) {
    return Column(

      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text("Netflix Originals", style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold, color: Colors.white),
        ),
        SizedBox(height:10),
        Container(

          width: double.infinity,
          height: 300,
          child: ListView(
            padding: const EdgeInsets.all(5),
            scrollDirection: Axis.horizontal,
            children:  [ Container(
              height: 400,
              width: 200,
              
             // radius: 50,
              child: Image.asset("assets/dogs.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            Container(
              height: 400,
              width: 200,
              
             // radius: 50,
              child: Image.asset("assets/thirteen_reasons.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            Container(
              height: 400,
              width: 200,
              
             // radius: 50,
              child: Image.asset("assets/sintel.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            Container(
              height: 400,
              width: 200,
              
             // radius: 50,
              child: Image.asset("assets/stranger_things.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            Container(
              height: 400,
              width: 200,
              
             // radius: 50,
              child: Image.asset("assets/witcher.jpg"),
              // child: Image.asset("assets/dogs.jpg"),
              
            ),
            
              
              
            //   CircleAvatar(
            //   radius: 50,
            //   backgroundImage: AssetImage("assets/thirteen_reasons.jpg"),
            //   // child: Image.asset("assets/dogs.jpg"),
            // ),
           
            // CircleAvatar(
            //   radius: 50,
            //   backgroundImage: AssetImage("assets/sintel.jpg"),
            //   //child: Image.asset("assets/dogs.jpg"),
            // ),
            // CircleAvatar(
            //   radius: 50,
            //   backgroundImage: AssetImage("assets/stranger_things.jpg"),
            //   //child: Image.asset("assets/dogs.jpg"),
            // ),
            // CircleAvatar(
            //   radius: 50,
            //   //child: Image.asset("assets/dogs.jpg"),
            //   backgroundImage: AssetImage("assets/witcher.jpg"),
            // ),
            
            ], 
          ),
        )



      ],
    );
  }
}