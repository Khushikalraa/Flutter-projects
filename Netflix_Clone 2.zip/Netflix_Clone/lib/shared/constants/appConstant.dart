import 'package:flutter/material.dart';

class appConstant{
  BuildContext context;
  appConstant({required this.context})
  
}