import 'package:flutter/material.dart';
import 'package:flutter_application_1/screen/bottomnav.dart';
// import 'package:flutter_application_1/screen/home.dart';
// import 'package:flutter_application_1/screen/homePage.dart';
// import 'package:flutter_application_1/widgets/nf_stack.dart';

void main() {
  runApp(MaterialApp(
    home: NavBar(), 
    debugShowCheckedModeBanner: false,)
  );
}

